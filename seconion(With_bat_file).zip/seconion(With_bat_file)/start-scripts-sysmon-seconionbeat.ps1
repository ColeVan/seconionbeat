Get-ChildItem "C:\Windows\Temp\seconion\" -Recurse | Unblock-File
$filepath= "'C:\\Windows\\Temp\\seconion\\seconionbeat-deploy-script.bat'"
Powershell -NonInteractive -ExecutionPolicy Bypass -Command Start-Process -filepath $filepath -ArgumentList '/S' -passthru -Wait -NoNewWindow